package com.example.my_awesome_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
